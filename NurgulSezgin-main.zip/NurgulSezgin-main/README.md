<p align="center">
  <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="40px"/>
  <img src="https://readme-typing-svg.herokuapp.com?font=Tapestry&size=25&duration=4000&background=1FE6C300&lines=Hello%2C+I'm+Nurg%C3%BCl..;Merhaba%2C+Ben+Nurg%C3%BCl.." width="300" /> 
  <!-- (https://git.io/typing-svg) -->
</p>

<div id="header" align="center">
  <img src="https://media.giphy.com/media/LMcB8XospGZO8UQq87/giphy.gif" width="350"/>
</div>
<div id="contact" align="center">
  <a href="https://www.linkedin.com/in/nurgül-sezgin" target="_blank"><img src="https://img.shields.io/badge/Linkedin%20-%230077B5.svg?&style=flat&logo=linkedin&logoColor=white" height="20" alt="LinkedIn Badge" /></a>
  <a href="mailto:nurgul_sezgin@hotmail.com" target="_blank"><img src="https://img.shields.io/badge/Email-0099ff?style=flat&logo=gmail&logoColor=white" height="20" alt="Email Badge"/></a>
  <a href="https://app.patika.dev/rosalie" target="blank"><img src="https://global-uploads.webflow.com/6097e0eca1e87557da031fef/609859a191abe5d64b17fed3_Patika%20logo-p-500.png" height="20" alt="Patika Badge"/></a>
</div>

## 👩‍💻 &nbsp;Tech Skills
![C#](https://img.shields.io/badge/-C%23-512BD4?style=flat&logo=dotnet)&nbsp;
![C++](https://img.shields.io/badge/-C++-00599C?style=flat&logo=cplusplus)&nbsp;
![SQL](https://img.shields.io/badge/-SQL-CC2927?style=flat&logo=microsoftsqlserver)&nbsp;
![HTML](https://img.shields.io/badge/-HTML-05122A?style=flat&logo=HTML5)&nbsp;
![CSS](https://img.shields.io/badge/-CSS-05122A?style=flat&logo=CSS3&logoColor=1572B6)&nbsp;
![JavaScript](https://img.shields.io/badge/-JavaScript-05122A?style=flat&logo=javascript)&nbsp;
![React Native](https://img.shields.io/badge/-React_Native-05122A?style=flat&logo=react)&nbsp;
![Python](https://img.shields.io/badge/-Python-E3CF57?style=flat&logo=python)&nbsp;
![Git](https://img.shields.io/badge/-Git-05122A?style=flat&logo=git)&nbsp;

## 💻 &nbsp;Tools
<p>
    <a href="https://code.visualstudio.com/" target="_blank"> <img alt="vscode" src="https://upload.wikimedia.org/wikipedia/commons/9/9a/Visual_Studio_Code_1.35_icon.svg" height="30"/> </a> &nbsp;
    <a href="https://visualstudio.microsoft.com/tr/vs/" target="_blank"> <img src="https://upload.wikimedia.org/wikipedia/commons/5/59/Visual_Studio_Icon_2019.svg" alt="heroku" height="30"/> </a> &nbsp;
    <a href="https://postman.com" target="_blank"> <img src="https://upload.wikimedia.org/wikipedia/commons/c/c2/Postman_%28software%29.png" alt="postman"  height="30"/> </a> &nbsp;
</p>

<br /><br />

## 🔥 &nbsp;My Stats 

<p >
    <a href="https://github.com/nurgulsezgin" target="_blank">
        <img align="center" height="160em" src="https://github-readme-stats.vercel.app/api?username=nurgulsezgin&show_icons=true&include_all_commits=true&theme=vision-friendly-dark&count_private=true&show_owner=true" />
        <img align="center" height="160em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=nurgulsezgin&layout=compact&theme=vision-friendly-dark"/>
    </a>
</p>

## 🐍 &nbsp;Snake eating my contribution graph

![Generate Snake](https://github.com/nurgulsezgin/NurgulSezgin/blob/output/github-contribution-grid-snake.gif)


